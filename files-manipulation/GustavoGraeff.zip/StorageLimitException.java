public class StorageLimitException extends Exception {
    public StorageLimitException(String message) {
        super(message);
    }
}
